package com.example.testFullCRUD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestFullCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
